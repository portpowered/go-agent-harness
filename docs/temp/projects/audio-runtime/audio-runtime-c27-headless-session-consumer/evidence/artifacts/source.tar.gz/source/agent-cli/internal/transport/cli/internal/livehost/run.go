package livehost

import (
	"context"
	"errors"
	"fmt"
	"io"
	"path/filepath"
	"strings"

	cliOutput "github.com/portpowered/go-agent-harness/agent-cli/internal/output"
	serviceSession "github.com/portpowered/go-agent-harness/agent-cli/internal/services/agentsession"
	runtimeDevices "github.com/portpowered/go-agent-harness/go-agent-runtime/services/devices"
	runtimeRecording "github.com/portpowered/go-agent-harness/go-agent-runtime/services/recording"
	runtimeReplay "github.com/portpowered/go-agent-harness/go-agent-runtime/services/replay"
	runtimeSession "github.com/portpowered/go-agent-harness/go-agent-runtime/services/session"
	"github.com/portpowered/go-agent-harness/go-audio/pkg/clock"
)

// FileDeviceService is the host-composed file media service and its timing
// role. The reusable runtime receives only the device service contract.
type FileDeviceService struct {
	Service   runtimeDevices.Service
	Scheduler clock.Scheduler
}

// RequestBuilder resolves CLI configuration into the neutral runtime request.
// It is deliberately a callback so this host package does not own provider,
// capability, or prompt policy.
type RequestBuilder func(context.Context, serviceSession.Request, *runtimeReplay.CaptureInspection) (runtimeSession.LiveRequest, error)

// AnnouncementWriter owns operator-facing startup text at the CLI boundary.
type AnnouncementWriter func(io.Writer, serviceSession.Request, runtimeSession.LiveRequest, *runtimeReplay.CaptureInspection) error

// Dependencies are the explicit host edges needed to run one live session.
// No process-wide discovery or default runtime graph is performed here.
type Dependencies struct {
	LiveService        runtimeSession.LiveService
	ReplayInspection   *runtimeReplay.CaptureInspection
	BuildRequest       RequestBuilder
	WriteAnnouncements AnnouncementWriter
	// AnnouncementOutput keeps operator-facing startup text off a binary audio
	// stream. When unset, Run preserves the historical behavior of writing
	// announcements to out.
	AnnouncementOutput io.Writer
	DeviceService      runtimeDevices.Service
	FileDeviceService  FileDeviceService
	RecordingService   runtimeRecording.Service
	CredentialValues   func(serviceSession.Request) ([]string, error)
	CaptureComplete    func(serviceSession.Request) []runtimeSession.LiveControl
}

// Run admits a single host invocation into the reusable live runtime. File
// sources and sinks are opened before admission and remain host-owned until
// this function joins the runtime. Provider, media, and terminal lifecycle
// policy remains in runtimeSession.LiveRunner.
func Run(ctx context.Context, out io.Writer, request serviceSession.Request, deps Dependencies) (runErr error) {
	runner, err := liveRunner(deps.LiveService)
	if err != nil {
		return err
	}
	if deps.BuildRequest == nil {
		return errors.New("live request builder is unavailable")
	}
	liveRequest, err := deps.BuildRequest(ctx, request, deps.ReplayInspection)
	if err != nil {
		return err
	}
	cleanupImages, err := stageLiveOpeningImages(request, &liveRequest)
	if err != nil {
		return err
	}
	defer func() { runErr = errors.Join(runErr, cleanupImages()) }()
	if deps.WriteAnnouncements != nil {
		announcementOut := deps.AnnouncementOutput
		if announcementOut == nil {
			announcementOut = out
		}
		if err := deps.WriteAnnouncements(announcementOut, request, liveRequest, deps.ReplayInspection); err != nil {
			return err
		}
	}
	recorder, err := openRecorder(request, &liveRequest, deps)
	if err != nil {
		return err
	}
	finishRecorder := func(cause error) error {
		if recorder == nil {
			return cause
		}
		return errors.Join(cause, recorder.Finalize(context.WithoutCancel(ctx), cause))
	}
	filePorts, err := OpenFilePorts(request, out, liveRequest.OutputAudioSampleRate)
	if err != nil {
		return finishRecorder(err)
	}
	if filePorts != nil {
		defer func() { runErr = errors.Join(runErr, filePorts.Close()) }()
	}
	configureLegacyReplayInput(filePorts, request, liveRequest)
	options := liveRunOptions(out, request, liveRequest, recorder, filePorts, deps)
	return suppressExpectedDuration(runner.RunLive(ctx, options))
}

// suppressExpectedDuration keeps the CLI's historical exit contract for an
// explicit max-duration stop while preserving every independent lifecycle
// failure joined by the runtime. The terminal event and recording still carry
// the duration classification; only the process exit value is translated.
func suppressExpectedDuration(err error) error {
	if err == nil {
		return nil
	}
	// Leave unrelated typed causes untouched. In particular, a scheduled
	// audio error carries its own concrete counters through Unwrap; traversing
	// that wrapper merely because it has an Unwrap method would replace the
	// type with the sentinel and break errors.As for the caller.
	if !errors.Is(err, runtimeSession.ErrLiveDurationExceeded) {
		return err
	}
	if joined, ok := err.(interface{ Unwrap() []error }); ok {
		return retainNonDurationCauses(joined.Unwrap())
	}
	if wrapped, ok := err.(interface{ Unwrap() error }); ok {
		cause := wrapped.Unwrap()
		if cause != nil {
			retained := suppressExpectedDuration(cause)
			if retained == nil {
				return nil
			}
			// Preserve the outer operation context while exposing the retained
			// cause to errors.Is/errors.As. This matters when a fmt.Errorf
			// wrapper surrounds an errors.Join(duration, independentFailure).
			return retainedLiveError{message: err.Error(), cause: retained}
		}
	}
	return nil
}

func retainNonDurationCauses(causes []error) error {
	kept := make([]error, 0, len(causes))
	for _, cause := range causes {
		if retained := suppressExpectedDuration(cause); retained != nil {
			kept = append(kept, retained)
		}
	}
	return errors.Join(kept...)
}

type retainedLiveError struct {
	message string
	cause   error
}

func (e retainedLiveError) Error() string { return e.message }

func (e retainedLiveError) Unwrap() error { return e.cause }

func liveRunner(service runtimeSession.LiveService) (runtimeSession.LiveRunner, error) {
	if service == nil {
		return nil, errors.New("live session runner is not configured")
	}
	runner, ok := service.(runtimeSession.LiveRunner)
	if !ok || runner == nil {
		return nil, errors.New("live session runner is not configured")
	}
	return runner, nil
}

func openRecorder(request serviceSession.Request, liveRequest *runtimeSession.LiveRequest, deps Dependencies) (runtimeSession.LiveRecorder, error) {
	if request.RecordDirectory == "" {
		recorder, err := openSemanticRecorder(request.RecordPath, deps.RecordingService)
		if err != nil || !request.TraceAudio {
			return recorder, err
		}
		traced, traceErr := newLiveTraceRecorder(recorder, ".", request.RecordPath, liveTraceProviderRate(liveRequest), liveTraceSource(deps.FileDeviceService.Scheduler))
		if traceErr != nil {
			if recorder != nil {
				traceErr = errors.Join(traceErr, recorder.Finalize(context.Background(), traceErr))
			}
			return nil, traceErr
		}
		return traced, nil
	}
	if err := validateLiveRecorderDependencies(deps); err != nil {
		return nil, err
	}
	replayInputPath := liveReplayInputPath(liveRequest)
	credentials, err := deps.CredentialValues(liveCredentialRequest(request, liveRequest))
	if err != nil {
		return nil, err
	}
	recorder, err := deps.RecordingService.OpenLiveEvidence(runtimeRecording.LiveEvidenceOptions{
		Destination:                   request.RecordDirectory,
		SessionID:                     liveRequest.SessionID,
		ParticipantID:                 liveRequest.ParticipantID,
		Provider:                      liveRequest.Provider,
		Model:                         liveRequest.Model,
		Credentials:                   credentials,
		ProviderCapturePath:           liveProviderCapturePath(request.RecordPath, replayInputPath),
		DisableProviderCaptureSidecar: replayInputPath != "" && request.RecordPath == "",
	})
	if err != nil {
		return nil, fmt.Errorf("open live recording: %w", err)
	}
	configureLiveCapturePath(request, replayInputPath, recorder, liveRequest)
	return traceLiveRecorderIfRequested(request, replayInputPath, recorder, liveRequest, deps)
}

func traceLiveRecorderIfRequested(request serviceSession.Request, replayInputPath string, recorder runtimeSession.LiveRecorder, liveRequest *runtimeSession.LiveRequest, deps Dependencies) (runtimeSession.LiveRecorder, error) {
	if !request.TraceAudio {
		return recorder, nil
	}
	providerPath := liveProviderCapturePath(request.RecordPath, replayInputPath)
	if providerPath == "" {
		providerPath = filepath.Join(request.RecordDirectory, "provider.json")
	}
	traced, err := newLiveTraceRecorder(recorder, request.RecordDirectory, providerPath, liveTraceProviderRate(liveRequest), liveTraceSource(deps.FileDeviceService.Scheduler))
	if err != nil {
		return nil, errors.Join(err, recorder.Finalize(context.Background(), err))
	}
	return traced, nil
}

func liveTraceProviderRate(liveRequest *runtimeSession.LiveRequest) int {
	if liveRequest == nil {
		return 0
	}
	if strings.TrimSpace(liveRequest.Replay.InputCapturePath) != "" {
		// A replayed provider can expose a file sink at a different rate from
		// the provider media boundary. The canonical realtime PCM rate is the
		// only safe fallback when the capture did not declare its native rate.
		if plan := liveRequest.ReplayPlan; plan == nil || plan.OutputAudioSampleRate <= 0 {
			return cliLiveDefaultRate
		}
	}
	if plan := liveRequest.ReplayPlan; plan != nil && plan.OutputAudioSampleRate <= 0 {
		return cliLiveDefaultRate
	}
	return liveRequest.OutputAudioSampleRate
}

func validateLiveRecorderDependencies(deps Dependencies) error {
	if deps.RecordingService == nil {
		return errors.New("live recording service is unavailable")
	}
	if deps.CredentialValues == nil {
		return errors.New("live credential resolver is unavailable")
	}
	return nil
}

func liveReplayInputPath(liveRequest *runtimeSession.LiveRequest) string {
	if liveRequest == nil {
		return ""
	}
	return strings.TrimSpace(liveRequest.Replay.InputCapturePath)
}

func liveProviderCapturePath(recordPath, replayInputPath string) string {
	if recordPath != "" {
		return recordPath
	}
	return replayInputPath
}

func liveCredentialRequest(request serviceSession.Request, liveRequest *runtimeSession.LiveRequest) serviceSession.Request {
	credentialRequest := request
	credentialRequest.ReplayPath = liveRequest.Replay.InputCapturePath
	credentialRequest.Provider = liveRequest.Provider
	credentialRequest.Model = liveRequest.Model
	credentialRequest.BaseURL = liveRequest.BaseURL
	return credentialRequest
}

func configureLiveCapturePath(request serviceSession.Request, replayInputPath string, recorder runtimeSession.LiveRecorder, liveRequest *runtimeSession.LiveRequest) {
	if request.RecordPath != "" || replayInputPath != "" {
		return
	}
	providerCapture, ok := recorder.(runtimeRecording.ProviderCapture)
	if !ok {
		return
	}
	path := strings.TrimSpace(providerCapture.ProviderCapturePath())
	if path != "" {
		configureCapturePath(liveRequest, path)
	}
}

func openSemanticRecorder(recordPath string, service runtimeRecording.Service) (runtimeSession.LiveRecorder, error) {
	if recordPath == "" {
		return nil, nil
	}
	if service == nil {
		return nil, errors.New("live recording service is unavailable")
	}
	recorder, err := service.OpenLiveSemanticEvidence(recordPath)
	if err != nil {
		return nil, fmt.Errorf("open live semantic recording: %w", err)
	}
	return recorder, nil
}

// configureCapturePath exists as a narrow hook for the caller-owned request
// copy. The recorder path is applied in Run before options are built.
func configureCapturePath(request *runtimeSession.LiveRequest, path string) {
	if request == nil || path == "" {
		return
	}
	request.Replay.OutputCapturePath = path
}

func configureLegacyReplayInput(filePorts *FilePorts, request serviceSession.Request, liveRequest runtimeSession.LiveRequest) {
	if filePorts == nil || filePorts.Input == nil || request.ReplayPath == "" || liveRequest.ReplayPlan == nil {
		return
	}
	if liveRequest.ReplayPlan.InputAudioSampleRate <= 0 {
		UseLegacyFrameSource(filePorts.Input)
	}
}

func liveRunOptions(out io.Writer, request serviceSession.Request, liveRequest runtimeSession.LiveRequest, recorder runtimeSession.LiveRecorder, filePorts *FilePorts, deps Dependencies) runtimeSession.LiveRunOptions {
	deviceService := deps.DeviceService
	deviceRequest := devicesRequest(request, liveRequest)
	if filePorts != nil {
		applyFileSchedulers(filePorts, deps.FileDeviceService.Scheduler)
		deviceRequest.FileInput = filePorts.Input
		deviceRequest.FileOutput = filePorts.Output
		deviceService, deviceRequest = selectFileDevices(deviceService, deps.FileDeviceService.Service, deviceRequest, filePorts)
	}
	if !deviceRequest.CaptureEnabled && !deviceRequest.PlaybackEnabled && (filePorts == nil || len(filePorts.InputTurns) == 0) {
		deviceService = nil
	}
	renderer := cliOutput.NewLiveEventRenderer(request.ReplayPath != "")
	return runtimeSession.LiveRunOptions{
		Request:                 liveRequest,
		Devices:                 deviceService,
		DeviceRequest:           deviceRequest,
		AudioTurnAdmission:      audioTurnAdmission(request),
		Recorder:                recorder,
		CaptureTurns:            captureTurns(filePorts),
		CaptureCompleteControls: captureCompleteControls(request, deps.CaptureComplete),
		Events: runtimeSession.LiveEventSinkFunc(func(eventContext context.Context, event runtimeSession.LiveEvent) error {
			eventOut := outputWriter(request, out)
			if err := renderer.Render(eventContext, eventOut, event); err != nil {
				return err
			}
			if request.StreamObserver != nil && event.Message != nil {
				request.StreamObserver(*event.Message)
			}
			return nil
		}),
	}
}
