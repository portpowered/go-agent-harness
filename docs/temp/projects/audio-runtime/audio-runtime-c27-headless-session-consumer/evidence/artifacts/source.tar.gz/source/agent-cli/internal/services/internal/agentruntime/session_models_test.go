package agentruntime

import sessioncontract "github.com/portpowered/go-agent-harness/agent-cli/internal/services/agentsession"

import (
	"context"
	"errors"
	"path/filepath"
	"strings"
	"testing"

	"github.com/portpowered/go-agent-harness/agent-cli/internal/config"
	"github.com/portpowered/go-agent-harness/go-agent-loop/pkg/messages"
	providerswire "github.com/portpowered/go-agent-harness/go-agent-runtime/services/providers/wire"
	"github.com/portpowered/go-agent-harness/go-llm-gateway/pkg/inference"
	"github.com/portpowered/go-agent-harness/go-llm-gateway/pkg/models"
	oaiprovider "github.com/portpowered/go-agent-harness/go-llm-gateway/pkg/providers/openai"
	"github.com/portpowered/go-agent-harness/go-llm-gateway/pkg/transport"
)

// These compatibility helpers are test-only. Production runtime code receives
// the provider-owned catalog through Dependencies and SessionRunOptions.
func testModelCatalog() interface {
	RealtimeModels(string) []OpenAIRealtimeModel
	LookupRealtimeModel(string, string) (OpenAIRealtimeModel, bool)
	SupportedRealtimeModelIDs(string) []string
} {
	return providerswire.NewModelCatalog()
}

func OpenAIRealtimeModels() []OpenAIRealtimeModel {
	return testModelCatalog().RealtimeModels("openai")
}

func SupportedOpenAIRealtimeModels() []OpenAIRealtimeModel { return OpenAIRealtimeModels() }

func LookupOpenAIRealtimeModel(model string) (OpenAIRealtimeModel, bool) {
	return testModelCatalog().LookupRealtimeModel("openai", model)
}

func TestOpenAIRealtimeModels_ReturnsOrderedIndependentRegistryCopy(t *testing.T) {
	models := OpenAIRealtimeModels()
	if len(models) != 3 {
		t.Fatalf("OpenAIRealtimeModels returned %d models, want 3", len(models))
	}

	wantIDs := []string{openAIRealtimeLegacyModel, openAIRealtimeDefaultModel, openAIRealtime21Model}
	for i, wantID := range wantIDs {
		if models[i].ID != wantID {
			t.Errorf("model %d ID = %q, want %q", i, models[i].ID, wantID)
		}
		if !models[i].SupportsAudio || !models[i].SupportsImageInput || !models[i].SupportsFunctionCalling {
			t.Errorf("model %q capabilities = %+v, want all supported", models[i].ID, models[i])
		}
	}

	models[0].ID = "mutated-by-caller"
	models[0].SupportsAudio = false
	got, ok := LookupOpenAIRealtimeModel(openAIRealtimeLegacyModel)
	if !ok {
		t.Fatal("legacy realtime model disappeared after caller mutation")
	}
	if got.ID != openAIRealtimeLegacyModel || !got.SupportsAudio {
		t.Fatalf("registry was mutated through returned slice: %+v", got)
	}
}

func TestLookupOpenAIRealtimeModel_MiniReportsCapabilities(t *testing.T) {
	model, ok := LookupOpenAIRealtimeModel(openAIRealtimeDefaultModel)
	if !ok {
		t.Fatal("mini realtime model was not registered")
	}
	if !model.SupportsAudio || !model.SupportsImageInput || !model.SupportsFunctionCalling {
		t.Fatalf("mini realtime model capabilities = %+v, want all supported", model)
	}

	if _, ok := LookupOpenAIRealtimeModel(strings.ToUpper(openAIRealtimeDefaultModel)); ok {
		t.Fatal("wrong-case realtime model should not be accepted")
	}
	if _, ok := LookupOpenAIRealtimeModel("not-a-model"); ok {
		t.Fatal("unknown realtime model should not be accepted")
	}
}

func TestNewOpenAIRealtimeSessionInferencer_UnsupportedModelsRejectBeforeDial(t *testing.T) {
	tests := []struct {
		name  string
		model string
	}{
		{name: "unknown", model: "not-a-model"},
		{name: "chat-only", model: "gpt-4o"},
		{name: "empty", model: ""},
		{name: "whitespace", model: "   "},
		{name: "wrong-case", model: "GPT-REALTIME-2.1-MINI"},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			dialer := &recordingOpenAIRealtimeDialer{}
			_, _, err := NewLiveSessionInferencer(SessionRunOptions{
				Provider: "openai", Model: tt.model, ModelProvided: true,
				APIKey: "test-key", ModelCatalog: testModelCatalog(), WebSocketDialer: dialer,
			}, "")
			if err == nil {
				t.Fatal("expected unsupported model error")
			}
			if !errors.Is(err, ErrUnsupportedRealtimeModel) {
				t.Fatalf("error = %v, want ErrUnsupportedRealtimeModel", err)
			}
			var unsupported *UnsupportedRealtimeModelError
			if !errors.As(err, &unsupported) {
				t.Fatalf("error = %v, want UnsupportedRealtimeModelError", err)
			}
			if unsupported.Model != tt.model {
				t.Fatalf("rejected model = %q, want %q", unsupported.Model, tt.model)
			}
			for _, supported := range []string{openAIRealtimeLegacyModel, openAIRealtimeDefaultModel, openAIRealtime21Model} {
				if !strings.Contains(err.Error(), supported) {
					t.Fatalf("error %q does not list supported model %q", err, supported)
				}
			}
			if dialer.calls != 0 {
				t.Fatalf("unsupported model attempted %d dials", dialer.calls)
			}
		})
	}
}

func TestNewOpenAIRealtimeSessionInferencer_SupportedModelsReachDialer(t *testing.T) {
	for _, model := range []string{openAIRealtimeLegacyModel, openAIRealtimeDefaultModel, openAIRealtime21Model} {
		t.Run(model, func(t *testing.T) {
			dialer := &recordingOpenAIRealtimeDialer{dialErr: errors.New("dial stopped by test")}
			inferencer, err := NewOpenAIRealtimeSessionInferencerWithOptions(
				configOpenAIRealtimeTestConfig(model),
				oaiprovider.WithRealtimeBaseURL("wss://test.openai.example/realtime"),
				oaiprovider.WithWebSocketDialer(dialer),
			)
			if err != nil {
				t.Fatalf("NewOpenAIRealtimeSessionInferencerWithOptions: %v", err)
			}

			_, err = inferencer.ConnectSession(context.Background())
			if err == nil || !strings.Contains(err.Error(), "dial stopped by test") {
				t.Fatalf("ConnectSession error = %v, want injected dial error", err)
			}
			if dialer.calls != 1 {
				t.Fatalf("dial calls = %d, want 1", dialer.calls)
			}
			if !strings.Contains(dialer.url, "model="+model) {
				t.Fatalf("dial URL = %q, want selected model %q", dialer.url, model)
			}
		})
	}
}

func TestNewLiveSessionInferencer_GPTRealtime21CarriesReasoningEffort(t *testing.T) {
	inferencer, model, err := NewLiveSessionInferencer(SessionRunOptions{
		ModelCatalog: testModelCatalog(),
		Provider:     config.ProviderOpenAI, Model: openAIRealtime21Model, ModelProvided: true,
		APIKey: "sk-test", BaseURL: "ws://openai.test/realtime", ConfigDir: t.TempDir(),
		ReasoningEffort: "high",
	}, "test")
	if err != nil {
		t.Fatalf("NewLiveSessionInferencer: %v", err)
	}
	requested := inferencer.(interface {
		Request() inference.SessionRequest
	})
	if model != openAIRealtime21Model || requested.Request().Config.ReasoningEffort != "high" {
		t.Fatalf("model/config = %q/%+v", model, requested.Request().Config)
	}
}

func TestValidateOpenAIRealtimeReasoningEffort(t *testing.T) {
	for _, effort := range []string{"", "minimal", "low", "medium", "high", "xhigh"} {
		if err := sessioncontract.ValidateOpenAIRealtimeReasoningEffort(effort); err != nil {
			t.Errorf("%q: %v", effort, err)
		}
	}
	if err := sessioncontract.ValidateOpenAIRealtimeReasoningEffort("extreme"); err == nil {
		t.Fatal("expected invalid effort error")
	}
}

func TestNewLiveSessionInferencerBuildsAudioSessionRequest(t *testing.T) {
	tests := []struct {
		name     string
		provider string
		model    string
		apiKey   string
		baseURL  string
		voice    string
	}{
		{name: "openai", provider: config.ProviderOpenAI, model: openAIRealtimeDefaultModel, apiKey: "sk-live-test", baseURL: "ws://openai.test/realtime", voice: "marin"},
		{name: "grok", provider: config.ProviderGrok, model: "grok-session-model", apiKey: "xai-live-test", baseURL: "ws://grok.test/realtime"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			inferencer, model, err := NewLiveSessionInferencer(SessionRunOptions{
				ModelCatalog: testModelCatalog(),
				Provider:     tt.provider,
				Model:        tt.model,
				APIKey:       tt.apiKey,
				BaseURL:      tt.baseURL,
				ConfigDir:    t.TempDir(),
				Voice:        tt.voice,
			}, "respond with the device probe phrase")
			if err != nil {
				t.Fatalf("NewLiveSessionInferencer: %v", err)
			}
			if inferencer == nil || model != tt.model {
				t.Fatalf("inferencer/model = (%T, %q), want non-nil inferencer and %q", inferencer, model, tt.model)
			}
			requested, ok := inferencer.(interface {
				Request() inference.SessionRequest
			})
			if !ok {
				t.Fatalf("inferencer type %T does not expose its session request", inferencer)
			}
			config := requested.Request().Config
			if config.Model != tt.model || config.Instructions != "respond with the device probe phrase" {
				t.Fatalf("session request identity = (%q, %q), want model/instructions", config.Model, config.Instructions)
			}
			if config.Voice != tt.voice {
				t.Fatalf("session voice = %q, want %q", config.Voice, tt.voice)
			}
			if len(config.Modalities) != 1 || config.Modalities[0] != models.SessionModalityAudio {
				t.Fatalf("session modalities = %#v, want audio only", config.Modalities)
			}
			if config.InputAudioFormat != models.AudioFormatPCM16 || config.OutputAudioFormat != models.AudioFormatPCM16 ||
				config.InputAudioSampleRate != models.SampleRate24000 || config.OutputAudioSampleRate != models.SampleRate24000 {
				t.Fatalf("session audio contract = %#v, want PCM16 at 24 kHz in both directions", config)
			}
		})
	}
}

func TestOpenAIRealtimeSessionVoiceIsPerInferencer(t *testing.T) {
	type result struct {
		voice string
		got   string
		err   error
	}

	voices := []string{"marin", "cedar"}
	results := make(chan result, len(voices))
	for _, voice := range voices {
		voice := voice
		go func() {
			inferencer, err := buildOpenAIRealtimeSessionInferencer(
				configOpenAIRealtimeTestConfig(openAIRealtimeDefaultModel),
				voice,
				&recordingOpenAIRealtimeDialer{},
			)
			if err != nil {
				results <- result{voice: voice, err: err}
				return
			}
			requested, ok := inferencer.(interface {
				Request() inference.SessionRequest
			})
			if !ok {
				results <- result{voice: voice, err: errors.New("inferencer does not expose its session request")}
				return
			}
			results <- result{voice: voice, got: requested.Request().Config.Voice}
		}()
	}

	for range voices {
		got := <-results
		if got.err != nil {
			t.Fatalf("build OpenAI session for %q: %v", got.voice, got.err)
		}
		if got.got != got.voice {
			t.Errorf("concurrent session voice = %q, want %q", got.got, got.voice)
		}
	}
}

func TestOpenAIRealtimeSessionVoicePreservesInstructionsAndTools(t *testing.T) {
	toolDefinitions := []messages.ToolDefinition{{Name: "lookup", Description: "Look up a value"}}
	inferencer, err := buildOpenAIRealtimeSessionInferencerWithInstructionsAndTools(
		configOpenAIRealtimeTestConfig(openAIRealtimeDefaultModel),
		"marin",
		&recordingOpenAIRealtimeDialer{},
		"Keep responses concise.",
		toolDefinitions,
	)
	if err != nil {
		t.Fatalf("build instruction-bearing OpenAI session: %v", err)
	}
	requested, ok := inferencer.(interface {
		Request() inference.SessionRequest
	})
	if !ok {
		t.Fatalf("inferencer type %T does not expose its session request", inferencer)
	}
	got := requested.Request().Config
	if got.Voice != "marin" || got.Instructions != "Keep responses concise." {
		t.Fatalf("session config = %#v, want voice and instructions", got)
	}
	if len(got.Tools) != 1 || got.Tools[0].Name != "lookup" {
		t.Fatalf("session tools = %#v, want lookup", got.Tools)
	}
}

func TestRunSession_OpenAIRealtimeDefaultAndOverridesReachDialer(t *testing.T) {
	for _, model := range []string{"", openAIRealtimeLegacyModel, openAIRealtimeDefaultModel} {
		name := model
		if name == "" {
			name = "default"
		}
		t.Run(name, func(t *testing.T) {
			configDir := t.TempDir()
			writeSessionConfigFile(t, configDir, `
model:
  provider: openai
  openai:
    api_key: sk-test-key
`)
			dialer := &recordingGrokRealtimeDialer{dialErr: errors.New("dial stopped by test")}
			_, _ = runOpenAIRealtimeWithDialer(t, configDir, model, dialer)
			if dialer.calls != 1 {
				t.Fatalf("dial calls = %d, want 1", dialer.calls)
			}
			wantModel := model
			if wantModel == "" {
				wantModel = openAIRealtimeDefaultModel
			}
			if !strings.Contains(dialer.url, "model="+wantModel) {
				t.Fatalf("dial URL = %q, want selected model %q", dialer.url, wantModel)
			}
		})
	}
}

func TestResolveOpenAIRealtimeSessionConfig_DefaultsWhenProviderConfigHasNoModel(t *testing.T) {
	configDir := t.TempDir()
	writeSessionConfigFile(t, configDir, `
model:
  provider: openai
`)

	got, err := resolveOpenAIRealtimeSessionConfig(SessionRunOptions{
		ModelCatalog: testModelCatalog(),
		Provider:     config.ProviderOpenAI,
		APIKey:       "sk-test-key",
		ConfigDir:    configDir,
	})
	if err != nil {
		t.Fatalf("resolveOpenAIRealtimeSessionConfig: %v", err)
	}
	if got.Model != openAIRealtimeDefaultModel {
		t.Fatalf("default realtime model = %q, want %q", got.Model, openAIRealtimeDefaultModel)
	}
}

// TestResolveOpenAIRealtimeSessionConfig_MissingAPIKeyRecommendsAPIKeyFlag
// guards the shared session-config helper's ordinary behavior: session, ask,
// and chat all expose --api-key, so their missing-credential error should
// keep recommending it. Only room run's bare-launch wrapper
// (bareRoomCredentialError in session_room_launch.go) substitutes
// environment-only guidance, because `room run` has no --api-key flag to
// recommend — see TestResolveBareRoomLaunchPlanMissingCredentialFailsBeforeDeviceAcquisition
// for that half of the contract.
func TestResolveOpenAIRealtimeSessionConfig_MissingAPIKeyRecommendsAPIKeyFlag(t *testing.T) {
	t.Setenv("OPENAI_API_KEY", "")
	t.Setenv(SessionOpenAIAPIKeyEnv, "")
	configDir := t.TempDir()
	writeSessionConfigFile(t, configDir, `
model:
  provider: openai
`)

	_, err := resolveOpenAIRealtimeSessionConfig(SessionRunOptions{
		ModelCatalog: testModelCatalog(),
		Provider:     config.ProviderOpenAI,
		ConfigDir:    configDir,
	})
	if err == nil {
		t.Fatal("resolveOpenAIRealtimeSessionConfig() = nil error, want a missing-credential error")
	}
	if !errors.Is(err, ErrOpenAIRealtimeAPIKeyMissing) {
		t.Fatalf("error = %v, want ErrOpenAIRealtimeAPIKeyMissing", err)
	}
	if !strings.Contains(err.Error(), "--api-key") {
		t.Fatalf("error = %v, want it to recommend --api-key", err)
	}
}

func TestRunSession_OpenAIRealtimeExplicitEmptyModelRejectsBeforeDial(t *testing.T) {
	configDir := t.TempDir()
	writeSessionConfigFile(t, configDir, `
model:
  provider: openai
  openai:
    api_key: sk-test-key
`)
	dialer := &recordingGrokRealtimeDialer{dialErr: errors.New("dial should not be reached")}

	err := RunSession(context.Background(), &strings.Builder{}, SessionRunOptions{
		ModelCatalog:    testModelCatalog(),
		RecordPath:      filepath.Join(t.TempDir(), "openai-session.json"),
		Provider:        config.ProviderOpenAI,
		ModelProvided:   true,
		ConfigDir:       configDir,
		WebSocketDialer: dialer,
	})
	if err == nil {
		t.Fatal("expected explicit empty model rejection")
	}
	if !errors.Is(err, ErrUnsupportedRealtimeModel) {
		t.Fatalf("error = %v, want ErrUnsupportedRealtimeModel", err)
	}
	var unsupported *UnsupportedRealtimeModelError
	if !errors.As(err, &unsupported) {
		t.Fatalf("error = %v, want UnsupportedRealtimeModelError", err)
	}
	if unsupported.Model != "" {
		t.Fatalf("rejected model = %q, want empty model", unsupported.Model)
	}
	if dialer.calls != 0 {
		t.Fatalf("explicit empty model attempted %d dials", dialer.calls)
	}
}

func TestResolveOpenAIRealtimeSessionConfig_WhitespaceOverrideIsTypedRejection(t *testing.T) {
	configDir := t.TempDir()
	writeSessionConfigFile(t, configDir, `
model:
  provider: openai
  openai:
    api_key: sk-test-key
`)

	_, err := resolveOpenAIRealtimeSessionConfig(SessionRunOptions{
		ModelCatalog: testModelCatalog(),
		Provider:     config.ProviderOpenAI,
		Model:        "   ",
		ConfigDir:    configDir,
	})
	if err == nil {
		t.Fatal("expected whitespace model rejection")
	}
	if !errors.Is(err, ErrUnsupportedRealtimeModel) {
		t.Fatalf("error = %v, want ErrUnsupportedRealtimeModel", err)
	}
}

func runOpenAIRealtimeWithDialer(t *testing.T, configDir, model string, dialer transport.Dialer) (string, error) {
	t.Helper()
	var out strings.Builder
	err := RunSession(context.Background(), &out, SessionRunOptions{
		ModelCatalog:    testModelCatalog(),
		RecordPath:      filepath.Join(t.TempDir(), "openai-session.json"),
		Provider:        config.ProviderOpenAI,
		Model:           model,
		ConfigDir:       configDir,
		WebSocketDialer: dialer,
	})
	return out.String(), err
}

func configOpenAIRealtimeTestConfig(model string) config.OpenAIConfig {
	return config.OpenAIConfig{APIKey: "sk-test-key", Model: model}
}

type recordingOpenAIRealtimeDialer struct {
	calls   int
	url     string
	dialErr error
}

var _ oaiprovider.WebSocketDialer = (*recordingOpenAIRealtimeDialer)(nil)

func (d *recordingOpenAIRealtimeDialer) Dial(url string, _ map[string]string) (oaiprovider.WebSocketConn, error) {
	d.calls++
	d.url = url
	return nil, d.dialErr
}

type recordingGrokRealtimeDialer struct {
	calls   int
	url     string
	dialErr error
}

var _ transport.Dialer = (*recordingGrokRealtimeDialer)(nil)

func (d *recordingGrokRealtimeDialer) Dial(url string, _ map[string]string) (transport.Conn, error) {
	d.calls++
	d.url = url
	return nil, d.dialErr
}
