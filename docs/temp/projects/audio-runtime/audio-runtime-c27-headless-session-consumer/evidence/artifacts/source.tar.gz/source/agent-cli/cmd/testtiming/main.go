package main

import (
	"bytes"
	"context"
	"flag"
	"fmt"
	"io"
	"os"
	"time"

	"github.com/portpowered/go-agent-harness/agent-cli/internal/testtimeout"
	"github.com/portpowered/go-agent-harness/agent-cli/internal/testtiming"
)

func main() {
	if err := run(os.Stdout, os.Stderr, os.Args[1:]); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}

func run(stdout, stderr io.Writer, args []string) error {
	flags := flag.NewFlagSet("testtiming", flag.ContinueOnError)
	flags.SetOutput(stderr)
	goCommand := flags.String("go", "go", "Go command to invoke")
	timeout := flags.String("timeout", "120s", "go test package timeout")
	top := flags.Int("top", 20, "number of slow package and test entries to print")
	if err := flags.Parse(args); err != nil {
		return err
	}
	timeoutDuration, err := time.ParseDuration(*timeout)
	if err != nil || timeoutDuration <= 0 {
		return fmt.Errorf("invalid positive test timeout %q", *timeout)
	}

	ctx := context.Background()
	preflightStarted := time.Now()
	preflightResult := runCommand(ctx, timeoutDuration, *goCommand, "test", "./...", "-run", "^$", "-count=1", "-timeout", *timeout)
	preflightDuration := time.Since(preflightStarted)
	if preflightResult.err != nil {
		_, _ = stderr.Write(preflightResult.combined)
		return fmt.Errorf("preflight no-test go test failed: %w", preflightResult.err)
	}

	suiteStarted := time.Now()
	suiteResult := runCommand(ctx, timeoutDuration, *goCommand, "test", "./...", "-json", "-v", "-count=1", "-timeout", *timeout)
	suiteDuration := time.Since(suiteStarted)

	summary, err := testtiming.Parse(bytes.NewReader(suiteResult.combined))
	if err != nil {
		return fmt.Errorf("parse go test JSON: %w", err)
	}
	if err := testtiming.WriteReport(stdout, summary, preflightDuration, suiteDuration, *top, suiteResult.exitCode); err != nil {
		return fmt.Errorf("write timing report: %w", err)
	}
	if suiteResult.err != nil {
		_, _ = stderr.Write(suiteResult.combined)
		return fmt.Errorf("suite go test failed: %w", suiteResult.err)
	}
	return nil
}

type commandResult struct {
	combined []byte
	exitCode int
	err      error
}

func runCommand(ctx context.Context, timeout time.Duration, name string, args ...string) commandResult {
	runnerResult, err := testtimeout.Run(ctx, testtimeout.Config{
		Command: name,
		Args:    args,
		Timeout: timeout,
	})
	return commandResult{
		combined: []byte(runnerResult.Output),
		exitCode: runnerResult.ExitCode,
		err:      err,
	}
}
