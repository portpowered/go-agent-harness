package cli

import (
	"context"
	"errors"
	"fmt"
	"io"
	"os"

	"github.com/portpowered/go-agent-harness/agent-cli/internal/flags"
	"github.com/portpowered/go-agent-harness/agent-cli/internal/input"
	"github.com/portpowered/go-agent-harness/agent-cli/internal/output"
	"github.com/portpowered/go-agent-harness/agent-cli/internal/services"
	"github.com/portpowered/go-agent-harness/go-agent-loop/pkg/agentloop"
	"github.com/portpowered/go-agent-harness/go-agent-runtime/services/session"
	"github.com/spf13/cobra"
)

const (
	defaultAskIterations      = 5
	defaultAskContextPressure = 0.8
)

// isStdinPiped returns true when stdin has been redirected/piped rather than
// connected to a terminal. In tests this is triggered by calling SetIn on the
// root command; in production it is triggered by a shell pipe or redirect.
func isStdinPiped(cmd *cobra.Command) bool {
	in := cmd.InOrStdin()
	if in != os.Stdin {
		// SetIn was called (e.g. in tests) — treat as piped.
		return true
	}
	stat, err := os.Stdin.Stat()
	if err != nil {
		return false
	}
	return (stat.Mode() & os.ModeCharDevice) == 0
}

// AskCommand wraps the ask subcommand for one-shot queries.
type AskCommand struct {
	service     session.Service
	askFlags    *flags.AskFlags
	loopFlags   *flags.LoopFlags
	globalFlags *flags.GlobalFlags
	runAsk      func(context.Context, *session.Request, agentloop.ExecuteInput) (string, error)
}

var (
	errAskExecution     = errors.New("ask execution failed")
	errAskLoopExecution = errors.New("ask loop execution failed")
	errAskLoopSummary   = errors.New("ask loop summary write failed")
	errAskInput         = errors.New("ask input construction failed")
	errAskFlagConflict  = errors.New("ask flag conflict")
	// errAskLoopTotalFailure identifies a loop that ran to completion (no
	// setup error) but never produced one successful iteration. Individual
	// iteration failures stay isolated per-iteration inside RunIterativeLoop
	// (the loop keeps trying fresh iterations, same as #321 keeps a room
	// running when one participant fails) — this is a CLI-boundary check on
	// top of that, so a run that accomplished nothing does not also print
	// "Loop complete" and exit 0.
	errAskLoopTotalFailure = errors.New("ask loop total failure")
)

type askCommandError struct {
	message    string
	identities []error
}

func (e *askCommandError) Error() string { return e.message }

func (e *askCommandError) Unwrap() []error { return e.identities }

func newAskCommandError(kind error, message string, cause error) error {
	identities := []error{kind}
	if cause != nil {
		identities = append(identities, cause)
	}
	return &askCommandError{message: message, identities: identities}
}

func wrapAskError(kind error, prefix string, cause error) error {
	return newAskCommandError(kind, fmt.Sprintf("%s: %v", prefix, cause), cause)
}

func tagAskError(kind error, cause error) error {
	return newAskCommandError(kind, cause.Error(), cause)
}

// loopRanAndAllIterationsFailed reports whether every recorded iteration of a
// completed loop run failed. An interrupted iteration (Ctrl+C) is not counted
// as a failure here: it is a deliberate, already-announced stop rather than
// the loop failing to do the requested work, and RunIterativeLoop reports it
// separately via its own "[Interrupted...]" banner.
func loopRanAndAllIterationsFailed(result session.IterativeResult) bool {
	if len(result.Iterations) == 0 {
		return false
	}
	for _, iteration := range result.Iterations {
		if iteration.Err == nil || errors.Is(iteration.Err, context.Canceled) {
			return false
		}
	}
	return true
}

// newAskLoopTotalFailureError names the problem for a loop that ran to
// completion without one successful iteration: exit 0 must mean the
// requested work actually happened, and a loop that only ever failed did not
// do the work "Loop complete" would otherwise claim.
func newAskLoopTotalFailureError(result session.IterativeResult) error {
	last := result.Iterations[len(result.Iterations)-1]
	return newAskCommandError(
		errAskLoopTotalFailure,
		fmt.Sprintf("loop ran %d iteration(s) and every one failed; last error (iteration %d): %v", len(result.Iterations), last.Iteration, last.Err),
		last.Err,
	)
}

// NewAskCommand creates the AskCommand with the given dependencies.
func NewAskCommand(service session.Service, askFlags *flags.AskFlags, loopFlags *flags.LoopFlags, globalFlags *flags.GlobalFlags) *AskCommand {
	return &AskCommand{service: service, askFlags: askFlags, loopFlags: loopFlags, globalFlags: globalFlags}
}

func validateAskFlags(cmd *cobra.Command, askFlags *flags.AskFlags, loopFlags *flags.LoopFlags) error {
	if askFlags.RecordCapturePath != "" && askFlags.ReplayCapturePath != "" {
		return newAskCommandError(errAskFlagConflict, "cannot use --record and --replay together", nil)
	}
	if askFlags.SessionID != "" && askFlags.ContinueLastSession {
		return newAskCommandError(errAskFlagConflict, "cannot use session ID and continue last session together", nil)
	}
	if loopFlags.Loop {
		if err := validateLoopFlagRanges(loopFlags); err != nil {
			return newAskCommandError(errAskFlagConflict, err.Error(), err)
		}
		return nil
	}
	for _, flag := range []string{"max-iterations", "stop-word", "context-pressure-threshold", "context-pressure-message", "trace-id"} {
		if cmd.Flags().Changed(flag) {
			return newAskCommandError(errAskFlagConflict, fmt.Sprintf("--%s requires --loop", flag), nil)
		}
	}
	return nil
}

// Generate returns the cobra command for ask.
func (c *AskCommand) Generate() *cobra.Command {
	cmd := &cobra.Command{
		Use:           "ask [prompt] [files...]",
		Short:         "Ask the agent a question and get a response",
		Long:          "One-shot queries. Pass a prompt and optional file paths for multimodal input.\nText can also be piped via stdin: echo \"question\" | yui ask",
		Example:       "  yui ask \"Summarize this repository\"\n  yui ask \"Describe this image\" screenshot.png",
		Args:          cobra.ArbitraryArgs,
		SilenceErrors: true,
		SilenceUsage:  true,
		RunE:          c.execute,
	}

	cmd.Flags().BoolVar(&c.askFlags.Stream, "stream", false, "Stream response tokens")
	cmd.Flags().StringVar(&c.askFlags.SystemPrompt, "system-prompt", "", "Path to system prompt file")
	cmd.Flags().BoolVar(&c.askFlags.ContinueLastSession, "continue-last-session", false, "Continue from the most recent session")
	cmd.Flags().StringVar(&c.askFlags.SessionID, "session-id", "", "Specific session ID to continue")
	cmd.Flags().StringVar(&c.askFlags.Model, "model", "", "Model ID (overrides config)")
	cmd.Flags().StringVar(&c.askFlags.Provider, "provider", "", "Provider ID (overrides config)")
	cmd.Flags().BoolVar(&c.askFlags.ShowToolUse, "show-tool-use", false, "Show tool invocations in output")
	cmd.Flags().StringVar(&c.askFlags.APIKey, "api-key", "", "API key (overrides config)")
	cmd.Flags().StringVar(&c.askFlags.BaseURL, "base-url", "", "Base URL for the provider (required with --provider local if no local config exists)")
	cmd.Flags().StringVar(&c.askFlags.RecordCapturePath, "record", "", "Record LLM HTTP traffic to file for replay")
	cmd.Flags().StringVar(&c.askFlags.ReplayCapturePath, "replay", "", "Replay LLM requests from a captured file (no live API)")
	cmd.Flags().BoolVar(&c.askFlags.OutputReasoningTokens, "output-reasoning-tokens", false, "Emit reasoning/thinking tokens to stdout when streaming")
	cmd.Flags().BoolVar(&c.askFlags.NoSystemInformation, "no-system-information", false, "Disable injection of runtime system info (OS, cwd, model, date) into the system prompt")
	cmd.Flags().BoolVar(&c.askFlags.OutputJSON, "output-json", false, "Output response as JSON; with --stream emits one NDJSON delta event per line")
	cmd.Flags().StringVar(&c.askFlags.OutputModality, "output-modality", "", "Output modality: text, image, audio, video, embedding (raw binary output for non-text modalities)")
	cmd.Flags().StringVar(&c.askFlags.ModelConfig, "model-config", "", "Model-specific config as JSON string (e.g. '{\"aspect_ratio\":\"16:9\",\"duration\":6}')")

	cmd.Flags().BoolVar(&c.loopFlags.Loop, "loop", false, "Enable iterative loop mode (re-instantiates fresh sessions up to --max-iterations)")
	cmd.Flags().IntVar(&c.loopFlags.MaxIterations, "max-iterations", defaultAskIterations, "Maximum number of loop iterations (requires --loop)")
	cmd.Flags().StringVar(&c.loopFlags.StopWord, "stop-word", "", "Stop the loop when this word appears in the response (requires --loop)")
	cmd.Flags().Float64Var(&c.loopFlags.ContextPressureThreshold, "context-pressure-threshold", defaultAskContextPressure, "Context pressure threshold 0-1 that triggers a context-full warning (requires --loop)")
	cmd.Flags().StringVar(&c.loopFlags.ContextPressureMessage, "context-pressure-message", "", "Custom warning message when context pressure threshold is exceeded (requires --loop)")
	cmd.Flags().StringVar(&c.loopFlags.TraceID, "trace-id", "", "Resume an existing loop run by trace ID (requires --loop)")

	return cmd
}

func (c *AskCommand) execute(cmd *cobra.Command, args []string) error {
	if err := validateAskFlags(cmd, c.askFlags, c.loopFlags); err != nil {
		return err
	}
	prompt, files := input.ParseAskArgs(args)
	var stdin io.Reader
	if isStdinPiped(cmd) {
		stdin = cmd.InOrStdin()
	}
	execInput, err := services.BuildExecuteInput(stdin, prompt, files)
	if err != nil {
		return tagAskError(errAskInput, err)
	}
	if c.service == nil {
		return wrapAskError(errAskExecution, "execution failed", errors.New("session service is not configured"))
	}
	request := services.BuildAgentConfigFromFlags(c.globalFlags, c.askFlags, nil, "")
	request.Input = execInput
	if c.loopFlags.Loop {
		return c.executeIterative(cmd, request)
	}
	if err := c.executeOneShot(cmd, request); err != nil {
		return wrapAskError(errAskExecution, "execution failed", err)
	}
	return nil
}

func (c *AskCommand) executeOneShot(cmd *cobra.Command, request *session.Request) error {
	if c.runAsk != nil {
		text, err := c.runAsk(cmd.Context(), request, request.Input)
		if err != nil {
			return err
		}
		return writeAskText(cmd.OutOrStdout(), text, c.askFlags.Stream)
	}
	if c.askFlags.Stream {
		return c.renderStreamingAsk(cmd.Context(), cmd, request, request.Input)
	}
	result, err := c.service.Run(cmd.Context(), *request)
	if err != nil {
		return err
	}
	return c.presentation(request).WriteResult(cmd.OutOrStdout(), cmd.ErrOrStderr(), result.Messages, result.Text)
}

func (c *AskCommand) executeIterative(cmd *cobra.Command, request *session.Request) error {
	maxIterations := c.loopFlags.MaxIterations
	if maxIterations <= 0 {
		maxIterations = defaultAskIterations
	}
	options := session.IterativeRequest{
		MaxIterations: maxIterations, StopWord: c.loopFlags.StopWord,
		ContextPressureThreshold: c.loopFlags.ContextPressureThreshold,
		ContextPressureMessage:   c.loopFlags.ContextPressureMessage, TraceID: c.loopFlags.TraceID,
	}
	result, err := c.service.RunIterative(cmd.Context(), *request, options)
	if err != nil {
		return wrapAskError(errAskLoopExecution, "loop execution failed", err)
	}
	if loopRanAndAllIterationsFailed(result) {
		return newAskLoopTotalFailureError(result)
	}
	return renderAskIterations(cmd.OutOrStdout(), result)
}

func renderAskIterations(writer io.Writer, result session.IterativeResult) error {
	if result.TraceID != "" {
		if _, err := fmt.Fprintf(writer, "Trace ID: %s\n", result.TraceID); err != nil {
			return wrapAskError(errAskLoopExecution, "loop execution failed: write trace ID", err)
		}
	}
	for _, iteration := range result.Iterations {
		if iteration.Text == "" {
			continue
		}
		if _, err := fmt.Fprintln(writer, iteration.Text); err != nil {
			return wrapAskError(errAskLoopExecution, "loop execution failed: write iteration output", err)
		}
	}
	if _, err := fmt.Fprintf(writer, "\n[Loop complete: %d iteration(s), completed: %v, trace: %s]\n", len(result.Iterations), result.Completed, result.TraceID); err != nil {
		return wrapAskError(errAskLoopSummary, "write loop summary", err)
	}
	return nil
}

// renderStreamingAsk owns invocation cleanup while the output package renders
// typed stream events. Provider deltas reach the host without final aggregation.
func (c *AskCommand) renderStreamingAsk(ctx context.Context, cmd *cobra.Command, request *session.Request, input agentloop.ExecuteInput) (resultErr error) {
	handle, err := c.service.Open(ctx, *request)
	if err != nil {
		return err
	}
	defer func() { resultErr = errors.Join(resultErr, handle.Close()) }()
	stream, err := handle.Stream(ctx, input)
	if err != nil {
		return err
	}
	defer func() { resultErr = errors.Join(resultErr, stream.Close()) }()
	if err := c.presentation(request).WriteStream(cmd.OutOrStdout(), cmd.ErrOrStderr(), stream); err != nil {
		return fmt.Errorf("write output: %w", err)
	}
	if err := stream.Err(); err != nil {
		return errors.Join(err, stream.Close())
	}
	if err := stream.Close(); err != nil {
		return err
	}
	if err := handle.Save(); err != nil {
		return err
	}
	return handle.Flush(request.RecordCapturePath)
}

func (c *AskCommand) presentation(request *session.Request) output.SessionPresentation {
	return output.SessionPresentation{JSON: c.askFlags.OutputJSON, Stream: c.askFlags.Stream, Modality: c.askFlags.OutputModality, Model: request.Model}
}

func writeAskText(writer io.Writer, text string, streaming bool) error {
	if err := output.WriteSessionText(writer, text, streaming); err != nil {
		return fmt.Errorf("write output: %w", err)
	}
	return nil
}
