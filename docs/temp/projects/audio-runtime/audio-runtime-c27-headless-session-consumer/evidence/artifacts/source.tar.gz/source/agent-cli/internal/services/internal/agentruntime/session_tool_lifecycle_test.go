package agentruntime

import (
	"context"
	"errors"
	"strings"
	"testing"

	"github.com/portpowered/go-agent-harness/go-agent-loop/pkg/messages"
)

func TestSessionProgressObserver_RejectedResultRegistersBeforeCallObservation(t *testing.T) {
	observer := newSessionProgressObserver(nil, nil, "grok", "grok-realtime")
	observer.setToolResultsEnabled(true)
	const callID = "call-rejected-before-observed"
	outcome := messages.SessionSendOutcome{
		Status: messages.SessionSendBufferFull,
		Err:    errors.New("result queue is full"),
	}

	// The provider result can race ahead of the outer delta consumer. Rejection
	// must create the obligation so terminal diagnostics cannot lose the ID.
	observer.noteToolResultRejected(callID, outcome)
	observer.observeProviderToolCall(messages.NewToolCallEndValue(callID, "slow_tool", "{}"))

	if got := observer.unresolvedToolCallIDs(); len(got) != 1 || got[0] != callID {
		t.Fatalf("unresolved IDs after rejected-before-observed call = %v, want [%s]", got, callID)
	}
	statuses := observer.unresolvedToolResultSendStatuses()
	if statuses[callID] != messages.SessionSendBufferFull {
		t.Fatalf("rejected send status = %q, want %q", statuses[callID], messages.SessionSendBufferFull)
	}

	// A later duplicate rejection must not replace the first observable status,
	// and acceptance of this ID must not affect any other obligation.
	observer.noteToolResultRejected(callID, messages.SessionSendOutcome{Status: messages.SessionSendClosed})
	observer.noteToolResultRejected("call-other", messages.SessionSendOutcome{Status: messages.SessionSendTerminalFailure})
	observer.noteToolResultAccepted(callID)

	got := observer.unresolvedToolCallIDs()
	if len(got) != 1 || got[0] != "call-other" {
		t.Fatalf("unresolved IDs after accepting one result = %v, want [call-other]", got)
	}
	if statuses := observer.unresolvedToolResultSendStatuses(); statuses[callID] != "" {
		t.Fatalf("accepted call retained rejection status %q", statuses[callID])
	}
}

func TestSessionProgressObserver_InterruptedProviderCallFailsWithCallID(t *testing.T) {
	sink := &diagnosticRecordSink{}
	observer := newSessionProgressObserver(sink, nil, "openai", "gpt-realtime")
	observer.setToolResultsEnabled(true)
	const callID = "call-interrupted-before-end"

	observer.observe(messages.StreamMessage{
		Type:       messages.StreamTypeToolCallStart,
		Role:       messages.RoleAssistant,
		ToolCallId: callID,
		Value:      messages.NewToolCallStartValue(callID, "lookup"),
	})
	if !observer.providerToolCallObserved() {
		t.Fatal("interrupted provider tool call was not recorded at TOOLCALL.START")
	}
	if got := observer.unresolvedToolCallIDs(); len(got) != 1 || got[0] != callID {
		t.Fatalf("interrupted provider tool IDs = %v, want [%s]", got, callID)
	}

	err := observer.finish(context.Canceled)
	if !errors.Is(err, context.Canceled) {
		t.Fatalf("interrupted provider call error = %v, want context.Canceled preserved", err)
	}
	if !errors.Is(err, ErrSessionUnresolvedToolResults) {
		t.Fatalf("interrupted provider call error = %v, want unresolved-result sentinel", err)
	}
	var unresolved *SessionUnresolvedToolResultsError
	if !errors.As(err, &unresolved) {
		t.Fatalf("interrupted provider call error = %v, want SessionUnresolvedToolResultsError", err)
	}
	if got := unresolved.UnresolvedCallIDs(); len(got) != 1 || got[0] != callID {
		t.Fatalf("interrupted provider unresolved IDs = %v, want [%s]", got, callID)
	}
	failures := sink.events(SessionDiagnosticEventFailure)
	if len(failures) != 1 {
		t.Fatalf("interrupted provider failure records = %d, want exactly one", len(failures))
	}
	if got := failures[0].Fields[SessionDiagnosticFieldUnresolvedToolCallIDs]; got != callID {
		t.Fatalf("interrupted provider diagnostic IDs = %q, want %s", got, callID)
	}

	// A terminal shutdown can recover a call committed to engine history even
	// when the consumer-facing delta was never drained.
	recovered := newSessionProgressObserver(nil, nil, "openai", "gpt-realtime")
	recovered.setToolResultsEnabled(true)
	recovered.observeBufferedProviderToolLifecycle([]messages.StreamMessage{
		{
			Type:       messages.StreamTypeToolCallStart,
			Role:       messages.RoleAssistant,
			ToolCallId: "call-recovered-from-history",
			Value:      messages.NewToolCallStartValue("call-recovered-from-history", "lookup"),
		},
	})
	if got := recovered.unresolvedToolCallIDs(); len(got) != 1 || got[0] != "call-recovered-from-history" {
		t.Fatalf("recovered provider unresolved IDs = %v, want [call-recovered-from-history]", got)
	}
}

func TestSessionProgressObserver_IncompleteResponseReportsAcceptedContinuationID(t *testing.T) {
	sink := &diagnosticRecordSink{}
	observer := newSessionProgressObserver(sink, nil, "openai", "gpt-realtime")
	observer.setToolResultsEnabled(true)
	const callID = "call-incomplete-continuation"
	observer.observe(messages.StreamMessage{
		Type:  messages.StreamTypeToolCallEnd,
		Role:  messages.RoleAssistant,
		Value: messages.NewToolCallEndValue(callID, "get_weather", `{"city":"Lisbon"}`),
	})
	observer.noteToolResultAccepted(callID)

	err := audioResponseCompletionError(nil, sessionLoopOptions{
		RequireAssistantResponse: true,
		observer:                 observer,
	})
	if !errors.Is(err, ErrSessionAudioResponseIncomplete) {
		t.Fatalf("incomplete response error = %v, want ErrSessionAudioResponseIncomplete", err)
	}
	err = observer.finish(err)
	if errors.Is(err, ErrSessionUnresolvedToolResults) {
		t.Fatalf("accepted result was reported as undelivered: %v", err)
	}
	if !errors.Is(err, ErrSessionToolContinuationIncomplete) {
		t.Fatalf("incomplete response error = %v, want tool continuation sentinel", err)
	}
	var continuationErr *SessionToolContinuationError
	if !errors.As(err, &continuationErr) {
		t.Fatalf("incomplete response error = %v, want SessionToolContinuationError", err)
	}
	if len(continuationErr.CallIDs) != 1 || continuationErr.CallIDs[0] != callID {
		t.Fatalf("continuation IDs = %v, want [%s]", continuationErr.CallIDs, callID)
	}
	failures := sink.events(SessionDiagnosticEventFailure)
	if len(failures) != 1 {
		t.Fatalf("failure records = %d, want exactly one", len(failures))
	}
	if got := failures[0].Fields[SessionDiagnosticFieldPendingToolContinuationIDs]; got != callID {
		t.Fatalf("pending tool continuation IDs = %q, want %s", got, callID)
	}
	if got := failures[0].Fields[fieldClassification]; got != SessionToolContinuationClassification {
		t.Fatalf("failure classification = %q, want %q", got, SessionToolContinuationClassification)
	}
}

func TestSessionProgressObserver_ImageContinuationWaitsForTerminalResponse(t *testing.T) {
	observer := newSessionProgressObserver(nil, nil, "openai", "gpt-realtime")
	observer.setToolResultsEnabled(true)
	const callID = "call-image-continuation"

	// Provider acceptance may be observed before the outer stream consumer sees
	// the completed function call. The later duplicate call event must attach to
	// the same accepted obligation rather than creating a second one.
	observer.noteToolResultAccepted(callID)
	observer.observe(messages.StreamMessage{
		Type:  messages.StreamTypeToolCallEnd,
		Role:  messages.RoleAssistant,
		Value: messages.NewToolCallEndValue(callID, "read_image", `{"path":"screen.png"}`),
	})
	observer.observe(messages.StreamMessage{
		Type:  messages.StreamTypeMessageEnd,
		Role:  messages.RoleAssistant,
		Value: messages.NewMessageEndValue(messages.TokenUsage{}),
	})

	if !observer.hasPendingImageContinuations() {
		t.Fatal("accepted read_image result was complete before its continuation")
	}
	if got := observer.pendingImageContinuationCallIDs(); len(got) != 1 || got[0] != callID {
		t.Fatalf("pending image continuation IDs = %v, want [%s]", got, callID)
	}
	if observer.hasUnresolvedToolCalls() {
		t.Fatal("accepted read_image result remained a generic unresolved result")
	}

	// A non-tool terminal MESSAGE.END is the continuation boundary. Duplicate
	// acceptance and duplicate terminal events must remain idempotent.
	observer.noteToolResultAccepted(callID)
	observer.noteToolContinuationRequested()
	observer.observe(messages.StreamMessage{
		Type:  messages.StreamTypeMessageStart,
		Role:  messages.RoleAssistant,
		Value: messages.NewMessageStartValue(),
	})
	observer.observe(messages.StreamMessage{
		Type:  messages.StreamTypeTextDelta,
		Role:  messages.RoleAssistant,
		Value: messages.NewTextDeltaValue("image described"),
	})
	observer.observe(messages.StreamMessage{
		Type:  messages.StreamTypeMessageEnd,
		Role:  messages.RoleAssistant,
		Value: &messages.MessageEndValue{Type: "message_end", Status: "completed"},
	})
	observer.observe(messages.StreamMessage{
		Type:  messages.StreamTypeMessageEnd,
		Role:  messages.RoleAssistant,
		Value: messages.NewMessageEndValue(messages.TokenUsage{}),
	})

	if observer.hasPendingImageContinuations() {
		t.Fatal("terminal image continuation remained pending after duplicate lifecycle events")
	}
	if got := observer.pendingImageContinuationCallIDs(); len(got) != 0 {
		t.Fatalf("pending image continuation IDs after terminal response = %v, want none", got)
	}
}

func TestSessionProgressObserver_ContinuationRequestBeforeCallObservation(t *testing.T) {
	observer := newSessionProgressObserver(nil, nil, "openai", "gpt-realtime")
	observer.setToolResultsEnabled(true)
	const callID = "call-continuation-before-observation"

	// Provider-send acknowledgements can reach the lifecycle observer before
	// the outer delta consumer drains the originating TOOLCALL.END. The request
	// must remain correlated with this call instead of being lost.
	observer.noteToolResultAccepted(callID)
	observer.noteToolContinuationRequested()
	observer.observe(messages.StreamMessage{
		Type:  messages.StreamTypeToolCallEnd,
		Role:  messages.RoleAssistant,
		Value: messages.NewToolCallEndValue(callID, "lookup", `{}`),
	})
	observer.observe(messages.StreamMessage{
		Type:  messages.StreamTypeMessageEnd,
		Role:  messages.RoleAssistant,
		Value: messages.NewMessageEndValue(messages.TokenUsage{}),
	})
	observer.observe(messages.StreamMessage{
		Type:  messages.StreamTypeMessageStart,
		Role:  messages.RoleAssistant,
		Value: messages.NewMessageStartValue(),
	})
	observer.observe(messages.StreamMessage{
		Type:  messages.StreamTypeTextDelta,
		Role:  messages.RoleAssistant,
		Value: messages.NewTextDeltaValue("lookup complete"),
	})
	observer.observe(messages.StreamMessage{
		Type:  messages.StreamTypeMessageEnd,
		Role:  messages.RoleAssistant,
		Value: &messages.MessageEndValue{Type: "message_end", Status: "completed"},
	})

	if observer.hasToolLifecycleObligation() {
		t.Fatal("out-of-order accepted continuation remained pending")
	}
	if got := observer.pendingToolContinuationCallIDs(); len(got) != 0 {
		t.Fatalf("pending continuation IDs = %v, want none", got)
	}
}

func TestShouldStopSessionLoopWaitsForReadImageResultAndContinuation(t *testing.T) {
	observer := newSessionProgressObserver(nil, nil, "openai", "gpt-realtime")
	observer.setToolResultsEnabled(true)
	const callID = "call-read-image"

	observer.observe(messages.StreamMessage{
		Type:  messages.StreamTypeToolCallEnd,
		Role:  messages.RoleAssistant,
		Value: messages.NewToolCallEndValue(callID, "read_image", `{}`),
	})
	providerToolCallEnd := messages.StreamMessage{
		Type:  messages.StreamTypeMessageEnd,
		Role:  messages.RoleAssistant,
		Value: messages.NewMessageEndValue(messages.TokenUsage{}),
	}
	observer.observe(providerToolCallEnd)
	if shouldStopSessionLoop(providerToolCallEnd, sessionLoopOptions{observer: observer}) {
		t.Fatal("provider read_image MESSAGE.END stopped before the tool result")
	}

	toolRunnerEnd := messages.StreamMessage{
		Type:  messages.StreamTypeMessageEnd,
		Role:  messages.RoleTool,
		Value: messages.NewMessageEndValue(messages.TokenUsage{}),
	}
	observer.observe(toolRunnerEnd)
	if shouldStopSessionLoop(toolRunnerEnd, sessionLoopOptions{observer: observer}) {
		t.Fatal("ToolRunner MESSAGE.END stopped before the model continuation")
	}

	observer.noteToolResultAccepted(callID)
	observer.noteToolContinuationRequested()
	observer.observe(messages.StreamMessage{
		Type:  messages.StreamTypeMessageStart,
		Role:  messages.RoleAssistant,
		Value: messages.NewMessageStartValue(),
	})
	observer.observe(messages.StreamMessage{
		Type:  messages.StreamTypeTextDelta,
		Role:  messages.RoleAssistant,
		Value: messages.NewTextDeltaValue("read image answer"),
	})
	finalAssistantEnd := messages.StreamMessage{
		Type:  messages.StreamTypeMessageEnd,
		Role:  messages.RoleAssistant,
		Value: &messages.MessageEndValue{Type: "message_end", Status: "completed"},
	}
	observer.observe(finalAssistantEnd)
	if !shouldStopSessionLoop(finalAssistantEnd, sessionLoopOptions{observer: observer}) {
		t.Fatal("completed read_image continuation did not stop the default session loop")
	}

	// Ordinary tools use the same continuation gate as image tools.
	genericObserver := newSessionProgressObserver(nil, nil, "openai", "gpt-realtime")
	genericObserver.setToolResultsEnabled(true)
	genericObserver.observe(messages.StreamMessage{
		Type:  messages.StreamTypeToolCallEnd,
		Role:  messages.RoleAssistant,
		Value: messages.NewToolCallEndValue("call-generic", "lookup", `{}`),
	})
	genericObserver.observe(providerToolCallEnd)
	if shouldStopSessionLoop(providerToolCallEnd, sessionLoopOptions{observer: genericObserver}) {
		t.Fatal("ordinary tool MESSAGE.END stopped before the tool result")
	}
}

func TestSessionProgressObserver_ImageContinuationFailurePreservesPrimaryCause(t *testing.T) {
	sink := &diagnosticRecordSink{}
	observer := newSessionProgressObserver(sink, nil, "openai", "gpt-realtime")
	observer.setToolResultsEnabled(true)
	const callID = "call-image-premature-close"
	observer.observe(messages.StreamMessage{
		Type:  messages.StreamTypeToolCallEnd,
		Role:  messages.RoleAssistant,
		Value: messages.NewToolCallEndValue(callID, "read_image", `{"path":"missing.png"}`),
	})
	observer.observe(messages.StreamMessage{
		Type:  messages.StreamTypeMessageEnd,
		Role:  messages.RoleAssistant,
		Value: messages.NewMessageEndValue(messages.TokenUsage{}),
	})
	observer.noteToolResultAccepted(callID)

	primary := errors.New("provider websocket closed")
	err := observer.finish(primary)
	if !errors.Is(err, primary) {
		t.Fatalf("finish error lost primary provider cause: %v", err)
	}
	if !errors.Is(err, ErrSessionImageContinuationIncomplete) {
		t.Fatalf("finish error = %v, want image continuation sentinel", err)
	}
	var continuationErr *SessionImageContinuationError
	if !errors.As(err, &continuationErr) {
		t.Fatalf("finish error = %v, want SessionImageContinuationError", err)
	}
	if len(continuationErr.CallIDs) != 1 || continuationErr.CallIDs[0] != callID {
		t.Fatalf("continuation error call IDs = %v, want [%s]", continuationErr.CallIDs, callID)
	}

	failures := sink.events(SessionDiagnosticEventFailure)
	if len(failures) != 1 {
		t.Fatalf("failure records = %d, want exactly one", len(failures))
	}
	if got := failures[0].Fields[SessionDiagnosticFieldPendingImageContinuationIDs]; got != callID {
		t.Fatalf("pending continuation diagnostic IDs = %q, want %s", got, callID)
	}
	if got := failures[0].Fields[fieldClassification]; got != SessionImageContinuationClassification {
		t.Fatalf("failure classification = %q, want %q", got, SessionImageContinuationClassification)
	}
}

func TestSessionProgressObserverContinuationRequiresSuccessfulObservableOutput(t *testing.T) {
	tests := []struct {
		name       string
		status     string
		detail     string
		reason     messages.TerminalReason
		outputType messages.StreamMessageType
		wantError  bool
	}{
		{name: "failed empty", status: "failed", detail: "reason=max_output_tokens", wantError: true},
		{name: "completed empty", status: "completed", wantError: true},
		{name: "completed text", status: "completed", outputType: messages.StreamTypeTextDelta},
		{name: "completed audio", status: "completed", outputType: messages.StreamTypeAudioDelta},
		{name: "server VAD supersedes continuation", status: "cancelled", detail: "reason=turn_detected, type=cancelled", reason: messages.TerminalReasonCancellation},
		{name: "provider close with partial text", reason: messages.TerminalReasonProviderClose, outputType: messages.StreamTypeTextDelta, wantError: true},
	}
	for _, tc := range tests {
		t.Run(tc.name, func(t *testing.T) {
			observer := newSessionProgressObserver(nil, nil, "openai", "gpt-realtime")
			observer.setToolResultsEnabled(true)
			const callID = "call-outcome"
			observer.observe(messages.StreamMessage{
				Type:  messages.StreamTypeToolCallEnd,
				Role:  messages.RoleAssistant,
				Value: messages.NewToolCallEndValue(callID, "read_image", `{"path":"photo.jpg"}`),
			})
			observer.observe(messages.StreamMessage{
				Type:  messages.StreamTypeMessageEnd,
				Role:  messages.RoleAssistant,
				Value: &messages.MessageEndValue{Type: "message_end", Status: "completed"},
			})
			observer.noteToolResultAccepted(callID)
			observer.noteToolContinuationRequested()
			observer.observe(messages.StreamMessage{
				Type:  messages.StreamTypeMessageStart,
				Role:  messages.RoleAssistant,
				Value: messages.NewMessageStartValue(),
			})
			if tc.outputType == messages.StreamTypeTextDelta {
				observer.observe(messages.StreamMessage{
					Type:  messages.StreamTypeTextDelta,
					Role:  messages.RoleAssistant,
					Value: messages.NewTextDeltaValue("a grounded answer"),
				})
			}
			if tc.outputType == messages.StreamTypeAudioDelta {
				observer.observe(messages.StreamMessage{
					Type:  messages.StreamTypeAudioDelta,
					Role:  messages.RoleAssistant,
					Value: messages.NewAudioDeltaValue([]byte{1, 2, 3}),
				})
			}
			terminal := &messages.MessageEndValue{Type: "message_end", Status: tc.status, StatusDetails: tc.detail, TerminalReason: tc.reason}
			terminalMessage := messages.StreamMessage{Type: messages.StreamTypeMessageEnd, Role: messages.RoleAssistant, Value: terminal}
			observer.observe(terminalMessage)

			if got := observer.hasTerminalToolContinuationFailure(); got != tc.wantError {
				t.Fatalf("terminal failure = %v, want %v", got, tc.wantError)
			}
			if got := shouldStopSessionLoop(terminalMessage, sessionLoopOptions{observer: observer, WaitForClose: true}); got != tc.wantError {
				t.Fatalf("wait-for-close stop = %v, want %v", got, tc.wantError)
			}
			if got := shouldStopAudioInputSessionLoop(terminalMessage, sessionLoopOptions{observer: observer, WaitForClose: true}, false, true); got != tc.wantError {
				t.Fatalf("audio wait-for-close stop = %v, want %v", got, tc.wantError)
			}
			err := observer.finish(nil)
			if tc.wantError {
				if err == nil {
					t.Fatal("failed or empty continuation returned nil")
				}
				var continuationErr *SessionImageContinuationError
				if !errors.As(err, &continuationErr) {
					t.Fatalf("continuation error = %v, want SessionImageContinuationError", err)
				}
				if len(continuationErr.CallIDs) != 1 || continuationErr.CallIDs[0] != callID {
					t.Fatalf("continuation IDs = %v, want [%s]", continuationErr.CallIDs, callID)
				}
				if tc.status != "" && continuationErr.ProviderStatuses[callID] != tc.status {
					t.Fatalf("provider status = %q, want %q", continuationErr.ProviderStatuses[callID], tc.status)
				}
				if tc.detail != "" && continuationErr.ProviderDetails[callID] != tc.detail {
					t.Fatalf("provider detail = %q, want %q", continuationErr.ProviderDetails[callID], tc.detail)
				}
				if tc.detail != "" && !strings.Contains(err.Error(), tc.detail) {
					t.Fatalf("error %q does not include provider detail %q", err, tc.detail)
				}
			} else if err != nil {
				t.Fatalf("successful continuation error = %v", err)
			}
		})
	}
}

func TestSessionProgressObserverFailedContinuationDiagnosticIsSingleAndActionable(t *testing.T) {
	sink := &diagnosticRecordSink{}
	observer := newSessionProgressObserver(sink, nil, "openai", "gpt-realtime")
	observer.setToolResultsEnabled(true)
	const callID = "call-failed-diagnostic"
	observer.observe(messages.StreamMessage{
		Type:  messages.StreamTypeToolCallEnd,
		Role:  messages.RoleAssistant,
		Value: messages.NewToolCallEndValue(callID, "read_image", `{}`),
	})
	observer.observe(messages.StreamMessage{
		Type:  messages.StreamTypeMessageEnd,
		Role:  messages.RoleAssistant,
		Value: &messages.MessageEndValue{Type: "message_end", Status: "completed"},
	})
	observer.noteToolResultAccepted(callID)
	observer.noteToolContinuationRequested()
	observer.observe(messages.StreamMessage{
		Type:  messages.StreamTypeMessageStart,
		Role:  messages.RoleAssistant,
		Value: messages.NewMessageStartValue(),
	})
	observer.observe(messages.StreamMessage{
		Type:  messages.StreamTypeMessageEnd,
		Role:  messages.RoleAssistant,
		Value: &messages.MessageEndValue{Type: "message_end", Status: "failed", StatusDetails: "reason=max_output_tokens"},
	})
	// A later duplicate-looking successful boundary must not erase the first
	// failed terminal cause or discharge the obligation.
	observer.observe(messages.StreamMessage{
		Type:  messages.StreamTypeMessageStart,
		Role:  messages.RoleAssistant,
		Value: messages.NewMessageStartValue(),
	})
	observer.observe(messages.StreamMessage{
		Type:  messages.StreamTypeTextDelta,
		Role:  messages.RoleAssistant,
		Value: messages.NewTextDeltaValue("late output"),
	})
	observer.observe(messages.StreamMessage{
		Type:  messages.StreamTypeMessageEnd,
		Role:  messages.RoleAssistant,
		Value: &messages.MessageEndValue{Type: "message_end", Status: "completed"},
	})
	if !observer.hasTerminalToolContinuationFailure() || !observer.hasToolLifecycleObligation() {
		t.Fatal("later successful boundary cleared the failed continuation obligation")
	}

	err := observer.finish(nil)
	if err == nil || !errors.Is(err, ErrSessionImageContinuationIncomplete) {
		t.Fatalf("failed continuation error = %v, want image continuation sentinel", err)
	}
	observer.finish(err)
	failures := sink.events(SessionDiagnosticEventFailure)
	if len(failures) != 1 {
		t.Fatalf("failure diagnostics = %d, want exactly one", len(failures))
	}
	fields := failures[0].Fields
	if fields[SessionDiagnosticFieldPendingImageContinuationIDs] != callID {
		t.Fatalf("diagnostic call IDs = %q, want %s", fields[SessionDiagnosticFieldPendingImageContinuationIDs], callID)
	}
	if fields[SessionDiagnosticFieldPendingContinuationStatuses] != callID+"=failed" {
		t.Fatalf("diagnostic statuses = %q, want %s", fields[SessionDiagnosticFieldPendingContinuationStatuses], callID+"=failed")
	}
	if fields[SessionDiagnosticFieldPendingContinuationDetails] != callID+"=reason=max_output_tokens" {
		t.Fatalf("diagnostic details = %q, want %s", fields[SessionDiagnosticFieldPendingContinuationDetails], callID+"=reason=max_output_tokens")
	}
}

func TestAudioResponseCompletionPreservesIncompleteWithOutputDiagnostic(t *testing.T) {
	pcmErr := errors.New("PCM16 audio delta has odd byte length 1")
	outputErr := errors.New("audio write response.wav: empty WAV samples")
	called := false
	err := audioResponseCompletionError(pcmErr, sessionLoopOptions{
		RequireTerminalAssistantResponse: true,
		AudioOutputError: func() error {
			called = true
			return outputErr
		},
	})
	if !called {
		t.Fatal("audio output completion callback was not awaited")
	}
	if !errors.Is(err, ErrSessionAudioResponseIncomplete) {
		t.Fatalf("completion error = %v, want ErrSessionAudioResponseIncomplete", err)
	}
	if !strings.Contains(err.Error(), pcmErr.Error()) {
		t.Fatalf("completion error = %v, want PCM diagnostic preserved", err)
	}
}
