package cli

import sessionclock "github.com/portpowered/go-agent-harness/go-audio/pkg/clock"

import sessionservicewire "github.com/portpowered/go-agent-harness/agent-cli/internal/services/wire"

import (
	"bytes"
	"context"
	"errors"
	"flag"
	"net/http"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	"github.com/portpowered/go-agent-harness/agent-cli/internal/config"
	"github.com/portpowered/go-agent-harness/agent-cli/internal/flags"
	runtimeSession "github.com/portpowered/go-agent-harness/go-agent-runtime/services/session"
	runtimeSessionWire "github.com/portpowered/go-agent-harness/go-agent-runtime/services/session/wire"
	"github.com/spf13/cobra"
	yamlv3 "gopkg.in/yaml.v3"
)

var updateGoldens = flag.Bool("update", false, "update CLI golden files")

type cliResult struct {
	stdout string
	stderr string
	err    error
}

func testFileStoreFactory() runtimeSession.FileStoreFactory {
	return runtimeSessionWire.NewFileStoreFactory()
}

func newGeneratedCLIRoot(configDir string) *cobra.Command {
	return newGeneratedCLIRootWithPathResolver(configDir, nil)
}

func newGeneratedCLIRootWithPathResolver(configDir string, resolver *pathResolver) *cobra.Command {
	globalFlags := flags.NewGlobalFlags()
	globalFlags.ConfigDirPath = configDir
	askFlags := flags.NewAskFlags()
	loopFlags := flags.NewLoopFlags()
	chatFlags := flags.NewChatFlags()

	router := NewRouter(
		globalFlags,
		NewRootCommand(globalFlags),
		NewAskCommand(nil, askFlags, loopFlags, globalFlags),
		NewChatCommand(nil, askFlags, loopFlags, chatFlags, globalFlags, testFileStoreFactory()),
		NewToolCommand(globalFlags),
		NewInteractionCommand(),
		NewInteractionReplayCommand(),
		NewProbeCommand(),
		NewProbeRunCommandWithDeviceService(newDevicesTestService(), nil, nil),
		NewProbeGateCommand(),
		NewProbeReportCommand(),
		NewProbeFleetCommand(nil, nil),
		NewSessionCommand(askFlags, globalFlags, newTestSessionService(sessionservicewire.SessionDependencies{Clock: sessionclock.Real{}}), nil),
		NewSessionShowCommand(globalFlags, testFileStoreFactory()),
		NewSessionListCommand(globalFlags, testFileStoreFactory()),
		NewSessionDeleteCommand(globalFlags, testFileStoreFactory()),
		NewSessionReplayCommand(nil),
		newTestRoomRunCommand(globalFlags, defaultTestDeviceRegistry{}),
		NewConfigCommand(),
		NewConfigAddLocalCommand(globalFlags),
		defaultTestDeviceRegistry{},
		newDevicesTestService(),
	)
	if resolver != nil {
		router.pathResolver = resolver
	}
	return NewAgentCLI(router).Generate()
}

func executeGeneratedCLI(ctx context.Context, configDir string, args ...string) cliResult {
	var stdout, stderr bytes.Buffer
	root := newGeneratedCLIRoot(configDir)
	root.SetOut(&stdout)
	root.SetErr(&stderr)
	root.SetArgs(args)
	err := root.ExecuteContext(ctx)
	return cliResult{stdout: stdout.String(), stderr: stderr.String(), err: err}
}

func TestConfigAddLocalS2FlagMatrix(t *testing.T) {
	configSummaryPath := filepath.Join("<config-dir>", config.ConfigFileName)
	tests := []configAddLocalCase{
		{
			name:    "default reachable config",
			baseURL: func(url string) string { return url },
			statuses: map[string]int{
				"/models": http.StatusOK,
			},
			model: "llama3",
			wantStdout: "Server reachable at <local-server>/models\n" +
				"Local provider added to " + configSummaryPath + "\n" +
				"  provider: local\n  base_url: <local-server>\n  model: llama3\n",
			wantPaths: []string{"/models"},
		},
		{
			name:    "non-default /v1 config",
			baseURL: func(url string) string { return url + "/v1" },
			statuses: map[string]int{
				"/v1/models": http.StatusOK,
			},
			seed:  nonDefaultConfig,
			model: "custom-local-model",
			wantStdout: "Server reachable at <local-server>/v1/models\n" +
				"Local provider added to " + configSummaryPath + "\n" +
				"  provider: local\n  base_url: <local-server>/v1\n  model: custom-local-model\n",
			wantPaths: []string{"/v1/models"},
		},
		{
			name:    "unreachable server warns and still persists",
			baseURL: func(url string) string { return url },
			statuses: map[string]int{
				"/models":    http.StatusServiceUnavailable,
				"/v1/models": http.StatusServiceUnavailable,
			},
			model:      "offline-model",
			wantStdout: "Local provider added to " + configSummaryPath + "\n  provider: local\n  base_url: <local-server>\n  model: offline-model\n",
			wantStderr: "Warning: could not reach server at <local-server> (server may not be running yet)\n",
			wantPaths:  []string{"/models", "/v1/models"},
		},
		{
			name:      "missing base url",
			model:     "llama3",
			wantError: `required flag(s) "base-url" not set`,
		},
		{
			name:      "missing model",
			baseURL:   func(url string) string { return url },
			wantError: `required flag(s) "model" not set`,
		},
		{
			name:      "missing required pair",
			wantError: `required flag(s) "base-url", "model" not set`,
		},
		{
			name:      "unsupported provider flag",
			baseURL:   func(url string) string { return url },
			model:     "llama3",
			wantError: "unknown flag: --provider",
		},
	}

	for _, tc := range tests {
		tc := tc
		t.Run(tc.name, func(t *testing.T) {
			runConfigAddLocalCase(t, tc)
		})
	}
}

func TestConfigAddLocalUsesIsolatedDefaultHome(t *testing.T) {
	home := t.TempDir()
	t.Setenv("HOME", home)
	t.Setenv("USERPROFILE", home)
	server := newProbeServer(t, map[string]int{"/models": http.StatusOK})
	defer server.Close()

	got := executeGeneratedCLI(context.Background(), "", "config", "add-local", "--base-url", server.URL, "--model", "home-model")
	if got.err != nil {
		t.Fatalf("execute config with default home: %v", got.err)
	}
	configPath := filepath.Join(home, config.ConfigDirName, config.ConfigFileName)
	rel, err := filepath.Rel(home, configPath)
	if err != nil || rel == ".." || strings.HasPrefix(rel, ".."+string(os.PathSeparator)) {
		t.Fatalf("config path escaped isolated home: %q", configPath)
	}
	info, err := os.Stat(configPath)
	if err != nil {
		t.Fatalf("config was not written below isolated home: %v", err)
	}
	if got := info.Mode().Perm(); got != 0o600 {
		t.Fatalf("new config mode = %o, want 600", got)
	}
}

func TestConfigAddLocalConcurrentUpdatesCommitExactlyOneRevision(t *testing.T) {
	configDir := t.TempDir()
	configPath := filepath.Join(configDir, config.ConfigFileName)
	if err := os.WriteFile(configPath, []byte(nonDefaultConfig), 0o600); err != nil {
		t.Fatalf("seed config: %v", err)
	}

	probesReady := make(chan struct{})
	releaseProbes := make(chan struct{})
	var probeCount atomic.Int32
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/models" {
			http.NotFound(w, r)
			return
		}
		if probeCount.Add(1) == 2 {
			close(probesReady)
		}
		<-releaseProbes
		w.WriteHeader(http.StatusOK)
	}))
	defer server.Close()

	results := make(chan cliResult, 2)
	var group sync.WaitGroup
	for _, model := range []string{"first-winner-candidate", "second-winner-candidate"} {
		model := model
		group.Add(1)
		go func() {
			defer group.Done()
			results <- executeGeneratedCLI(context.Background(), configDir, "--config-dir", configDir, "config", "add-local", "--base-url", server.URL, "--model", model)
		}()
	}

	select {
	case <-probesReady:
	case <-time.After(5 * time.Second):
		close(releaseProbes)
		t.Fatal("both add-local commands did not reach the probe")
	}
	close(releaseProbes)
	group.Wait()
	close(results)

	successes := 0
	conflicts := 0
	winner := ""
	for result := range results {
		if result.err == nil {
			successes++
			for _, model := range []string{"first-winner-candidate", "second-winner-candidate"} {
				if strings.Contains(result.stdout, "  model: "+model+"\n") {
					winner = model
				}
			}
			continue
		}
		if errors.Is(result.err, config.ErrConfigRevisionConflict) {
			conflicts++
			if strings.Contains(result.stdout, "Local provider added") {
				t.Fatalf("conflicting command printed success: %q", result.stdout)
			}
			if !strings.Contains(result.err.Error(), filepath.Clean(configPath)) {
				t.Fatalf("conflict error = %v, want config path", result.err)
			}
			continue
		}
		t.Fatalf("unexpected add-local error: %v", result.err)
	}
	if successes != 1 || conflicts != 1 || winner == "" {
		t.Fatalf("successes=%d conflicts=%d winner=%q, want one success and one conflict", successes, conflicts, winner)
	}

	data, err := os.ReadFile(configPath)
	if err != nil {
		t.Fatalf("read final config: %v", err)
	}
	var final config.Config
	if err := yamlv3.Unmarshal(data, &final); err != nil {
		t.Fatalf("parse final config: %v", err)
	}
	if final.Model.Provider != config.ProviderLocal || final.Model.Local == nil || final.Model.Local.Model != winner {
		t.Fatalf("final config local provider = %#v, want winner %q", final.Model.Local, winner)
	}
}

func TestConfigAddLocalRejectsExternalRevisionDuringProbe(t *testing.T) {
	configDir := t.TempDir()
	configPath := filepath.Join(configDir, config.ConfigFileName)
	original := []byte(nonDefaultConfig)
	newer := []byte("model:\n  provider: openrouter\n  openrouter:\n    model: external-winner\n")
	if err := os.WriteFile(configPath, original, 0o600); err != nil {
		t.Fatalf("seed config: %v", err)
	}

	probeStarted := make(chan struct{})
	releaseProbe := make(chan struct{})
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path != "/models" {
			http.NotFound(w, r)
			return
		}
		close(probeStarted)
		<-releaseProbe
		w.WriteHeader(http.StatusOK)
	}))
	defer server.Close()

	result := make(chan cliResult, 1)
	go func() {
		result <- executeGeneratedCLI(context.Background(), configDir, "--config-dir", configDir, "config", "add-local", "--base-url", server.URL, "--model", "should-not-commit")
	}()
	select {
	case <-probeStarted:
	case <-time.After(5 * time.Second):
		close(releaseProbe)
		t.Fatal("add-local command did not reach the probe")
	}
	if err := os.WriteFile(configPath, newer, 0o600); err != nil {
		close(releaseProbe)
		t.Fatalf("write external revision: %v", err)
	}
	close(releaseProbe)

	got := <-result
	if got.err == nil || !errors.Is(got.err, config.ErrConfigRevisionConflict) {
		t.Fatalf("command error = %v, want config revision conflict", got.err)
	}
	if strings.Contains(got.stdout, "Local provider added") {
		t.Fatalf("conflicting command printed success: %q", got.stdout)
	}
	if !strings.Contains(got.err.Error(), filepath.Clean(configPath)) {
		t.Fatalf("conflict error = %v, want config path", got.err)
	}
	data, err := os.ReadFile(configPath)
	if err != nil {
		t.Fatalf("read external revision: %v", err)
	}
	if string(data) != string(newer) {
		t.Fatalf("external revision changed to %q, want unchanged bytes", data)
	}
}

func TestConfigAddLocalInvalidConfigHasCommandContext(t *testing.T) {
	configDir := t.TempDir()
	if err := os.WriteFile(filepath.Join(configDir, config.ConfigFileName), []byte("model: ["), 0600); err != nil {
		t.Fatalf("write invalid config: %v", err)
	}

	got := executeGeneratedCLI(context.Background(), configDir, "--config-dir", configDir, "config", "add-local", "--base-url", "http://127.0.0.1:1", "--model", "broken")
	if got.err == nil {
		t.Fatal("expected invalid config error")
	}
	if !strings.Contains(got.err.Error(), "load config") || !strings.Contains(got.err.Error(), "config.yaml") {
		t.Fatalf("error = %q, want load context and config path", got.err)
	}
}

func TestConfigRenderingS3Goldens(t *testing.T) {
	for _, tc := range []struct {
		name   string
		seed   string
		model  string
		golden string
	}{
		{name: "default", model: "llama3", golden: "config_default.yaml"},
		{name: "non-default", seed: nonDefaultConfig, model: "custom-local-model", golden: "config_non_default.yaml"},
	} {
		t.Run(tc.name, func(t *testing.T) {
			configDir := t.TempDir()
			if tc.seed != "" {
				if err := os.WriteFile(filepath.Join(configDir, config.ConfigFileName), []byte(tc.seed), 0600); err != nil {
					t.Fatalf("seed config: %v", err)
				}
			}
			server := newProbeServer(t, map[string]int{"/v1/models": http.StatusOK})
			defer server.Close()
			baseURL := server.URL
			if tc.seed != "" {
				baseURL += "/v1"
			}
			got := executeGeneratedCLI(context.Background(), configDir, "--config-dir", configDir, "config", "add-local", "--base-url", baseURL, "--model", tc.model)
			if got.err != nil {
				t.Fatalf("execute golden command: %v", got.err)
			}
			data, err := os.ReadFile(filepath.Join(configDir, config.ConfigFileName))
			if err != nil {
				t.Fatalf("read golden config: %v", err)
			}
			assertConfigGolden(t, tc.golden, normalizeCLIOutput(string(data), configDir, server.URL))
		})
	}
}

func TestConfigRenderingRedactsEnvironmentAPIKey(t *testing.T) {
	const sentinel = "s2s-config-redaction-sentinel-20260816"
	for _, envName := range []string{
		"AGENT_MODEL__OPENAI__API_KEY",
		"AGENT_MODEL__CLAUDE__API_KEY",
		"AGENT_MODEL__OPENROUTER__API_KEY",
		"AGENT_MODEL__LOCAL__API_KEY",
		"AGENT_MODEL__FAL__API_KEY",
		"AGENT_MODEL__GROK__API_KEY",
	} {
		t.Setenv(envName, sentinel)
	}
	configDir := t.TempDir()
	server := newProbeServer(t, map[string]int{"/models": http.StatusOK})
	defer server.Close()

	got := executeGeneratedCLI(context.Background(), configDir, "--config-dir", configDir, "config", "add-local", "--base-url", server.URL, "--model", "redaction-model")
	if got.err != nil {
		t.Fatalf("execute config redaction case: %v", got.err)
	}
	data, err := os.ReadFile(filepath.Join(configDir, config.ConfigFileName))
	if err != nil {
		t.Fatalf("read rendered config: %v", err)
	}
	rendered := got.stdout + got.stderr + string(data)
	if strings.Contains(rendered, sentinel) {
		t.Fatalf("rendered config must omit environment secret %q", sentinel)
	}
	if !strings.Contains(rendered, redactedAPIKey) {
		t.Fatalf("rendered config must omit the environment secret and include <redacted>")
	}
}

type failOnWrite struct {
	failAt int
	writes int
	err    error
}

func (w *failOnWrite) Write(p []byte) (int, error) {
	w.writes++
	if w.writes == w.failAt {
		return 0, w.err
	}
	return len(p), nil
}

func TestConfigAddLocalSummaryWriteFailures(t *testing.T) {
	for _, tc := range []struct {
		name   string
		failAt int
	}{
		{name: "provider summary", failAt: 3},
		{name: "base URL summary", failAt: 4},
		{name: "model summary", failAt: 5},
	} {
		t.Run(tc.name, func(t *testing.T) {
			server := newProbeServer(t, map[string]int{"/models": http.StatusOK})
			defer server.Close()

			globalFlags := flags.NewGlobalFlags()
			globalFlags.ConfigDirPath = t.TempDir()
			cmd := &cobra.Command{}
			cmd.SetOut(&failOnWrite{failAt: tc.failAt, err: errors.New("summary write failed")})
			cmd.SetErr(&bytes.Buffer{})

			configCmd := NewConfigAddLocalCommand(globalFlags)
			configCmd.baseURL = server.URL
			configCmd.model = "test-model"
			err := configCmd.run(cmd)
			if err == nil || !strings.Contains(err.Error(), "write config summary") {
				t.Fatalf("run error = %v, want write config summary context", err)
			}
		})
	}
}

const nonDefaultConfig = `model:
  provider: openrouter
  openrouter:
    model: seeded-model
    base_url: https://example.test/v1
  continuation_nudge_enabled: true
  continuation_nudge_message: continue now
  repetition_penalty: 1.25
tools:
  exec:
    enable_deny_patterns: false
    custom_deny_patterns:
      - seeded-pattern
  list:
    - id: exec
      enabled: false
    - id: sleep
      enabled: true
`

type probeServer struct {
	*httptest.Server
	paths []string
}

func newProbeServer(t *testing.T, statuses map[string]int) *probeServer {
	t.Helper()
	server := &probeServer{}
	server.Server = httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		server.paths = append(server.paths, r.URL.Path)
		status := statuses[r.URL.Path]
		if status == 0 {
			status = http.StatusNotFound
		}
		w.WriteHeader(status)
	}))
	return server
}

func normalizeCLIOutput(value, configDir, serverURL string) string {
	value = strings.ReplaceAll(value, serverURL, "<local-server>")
	return strings.ReplaceAll(value, filepath.Clean(configDir), "<config-dir>")
}

func assertConfigGolden(t *testing.T, name, got string) {
	t.Helper()
	path := filepath.Join("testdata", name)
	if *updateGoldens {
		if err := os.MkdirAll(filepath.Dir(path), 0755); err != nil {
			t.Fatalf("create golden directory: %v", err)
		}
		if err := os.WriteFile(path, []byte(got), 0600); err != nil {
			t.Fatalf("write golden %s: %v", path, err)
		}
		return
	}
	want, err := os.ReadFile(path)
	if err != nil {
		t.Fatalf("read golden %s (run with -update only when intentionally regenerating): %v", path, err)
	}
	if string(want) != got {
		t.Fatalf("golden %s mismatch:\n--- got ---\n%s\n--- want ---\n%s", name, got, want)
	}
}
